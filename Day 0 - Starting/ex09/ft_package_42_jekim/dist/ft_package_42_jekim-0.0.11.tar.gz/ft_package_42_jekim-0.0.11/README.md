# ft_package : Example package for Python_For_DataScience

This is an example package for the Python_For_DataScience course.